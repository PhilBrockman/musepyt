#!/usr/bin/env python
# coding: utf-8

# In[ ]:


try:
  import pretty_midi
except:
  get_ipython().system(u'pip install pretty_midi')

def a3():
  print("foobar")

