#!/usr/bin/env python
# coding: utf-8

# In[ ]:





# In[ ]:


if __name__ == "__main__":
  print("why are you here?")


# In[5]:


def d():
  return "subsub"


# In[ ]:





# In[ ]:




